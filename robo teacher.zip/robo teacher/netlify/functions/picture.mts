// Draws a lesson picture (story scene or visual diagram) with a Gemini image model.
// Pictures are cached in Blobs by prompt, so each one is only drawn once.
import type { Config } from '@netlify/functions'
import { GoogleGenAI } from '@google/genai'
import { getStore } from '@netlify/blobs'
import { createHash } from 'node:crypto'

const ai = new GoogleGenAI({
  apiKey: process.env.NETLIFY_AI_GATEWAY_KEY,
  httpOptions: { baseUrl: process.env.NETLIFY_AI_GATEWAY_URL?.replace(/\/$/, '') },
})

const STYLE: Record<string, string> = {
  scene:
    "A children's picture-book illustration for a school student in India. Landscape 4:3 frame, bright warm colours, soft rounded shapes, friendly expressive characters, simple uncluttered background. Do not put any words, letters or numbers in the image. Scene: ",
  visual:
    'A clear, colourful educational diagram for a school student. Landscape 4:3 frame, flat vector style, white background, large simple shapes and arrows, at most a few short English labels, spelled correctly. Show: ',
}

export default async (req: Request) => {
  const { prompt, kind } = await req.json().catch(() => ({}))
  if (typeof prompt !== 'string' || !prompt.trim() || prompt.length > 600) {
    return Response.json({ error: 'Invalid prompt' }, { status: 400 })
  }
  const full = (STYLE[kind] ?? STYLE.scene) + prompt.trim()
  const key = createHash('sha256').update(full).digest('hex').slice(0, 32)
  const store = getStore('pictures')

  const existing = await store.getMetadata(key)
  if (existing) return Response.json({ key })

  try {
    const res = await ai.models.generateContent({ model: 'gemini-3.1-flash-image', contents: full })
    const part = res.candidates?.[0]?.content?.parts?.find((p) => p.inlineData?.data)
    if (!part?.inlineData?.data) return Response.json({ error: 'No picture' }, { status: 502 })
    const bytes = Buffer.from(part.inlineData.data, 'base64')
    await store.set(key, new Blob([bytes]), {
      metadata: { contentType: part.inlineData.mimeType || 'image/png' },
    })
    return Response.json({ key })
  } catch (e) {
    console.error('picture error', e)
    return Response.json({ error: 'Picture unavailable' }, { status: 502 })
  }
}

export const config: Config = { path: '/api/picture', method: 'POST' }