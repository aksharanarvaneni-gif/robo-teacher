// Serves stored lesson pictures; the page loads them through the Image CDN.
import type { Config, Context } from '@netlify/functions'
import { getStore } from '@netlify/blobs'

export default async (_req: Request, context: Context) => {
  const res = await getStore('pictures').getWithMetadata(context.params.key, { type: 'stream' })
  if (!res) return new Response('Not found', { status: 404 })
  return new Response(res.data, {
    headers: {
      'Content-Type': (res.metadata?.contentType as string) || 'image/png',
      'Cache-Control': 'public, max-age=31536000, immutable',
    },
  })
}

export const config: Config = { path: '/pics/:key' }