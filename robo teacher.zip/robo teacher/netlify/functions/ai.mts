// Robo Teacher's brain: answers a prompt with text via Netlify AI Gateway.
// Lessons with a cacheKey are stored in Blobs so every student gets them instantly.
import type { Config } from '@netlify/functions'
import { GoogleGenAI } from '@google/genai'
import { getStore } from '@netlify/blobs'
import { createHash } from 'node:crypto'

const ai = new GoogleGenAI({})
const MAX_PROMPT = 8000

export default async (req: Request) => {
  const { prompt, cacheKey } = await req.json().catch(() => ({}))
  if (typeof prompt !== 'string' || !prompt.trim() || prompt.length > MAX_PROMPT) {
    return Response.json({ error: 'Invalid prompt' }, { status: 400 })
  }

  const store = getStore('lessons')
  const key = typeof cacheKey === 'string' && cacheKey ? 'v1-' + createHash('sha256').update(cacheKey).digest('hex') : null
  if (key) {
    const hit = await store.get(key, { type: 'text' })
    if (hit) return Response.json({ text: hit })
  }

  try {
    const res = await ai.models.generateContent({ model: 'gemini-3-flash-preview', contents: prompt })
    const text = res.text ?? ''
    if (key && text) {
      // Only cache replies that are valid JSON lessons
      try {
        JSON.parse(text.replace(/```json|```/g, '').trim())
        await store.set(key, text)
      } catch {}
    }
    return Response.json({ text })
  } catch (e) {
    console.error('ai error', e)
    return Response.json({ error: 'AI unavailable' }, { status: 502 })
  }
}

export const config: Config = { path: '/api/ai', method: 'POST' }

netlify/functions/pics.mts
added
+16
// Serves stored lesson pictures; the page loads them through the Image CDN.
import type { Config, Context } from '@netlify/functions'
import { getStore } from '@netlify/blobs'

export default async (_req: Request, context: Context) => {
  const res = await getStore('pictures').getWithMetadata(context.params.key, { type: 'stream' })
  if (!res) return new Response('Not found', { status: 404 })
  return new Response(res.data, {
    headers: {
      'Content-Type': (res.metadata?.contentType as string) || 'image/png',
      'Cache-Control': 'public, max-age=31536000, immutable',
    },
  })
}

export const config: Config = { path: '/pics/:key' }