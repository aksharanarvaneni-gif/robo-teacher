EADME.md
added
+29
# Robo Teacher

Robo is a friendly AI teacher for Telangana State Board students, from Nursery to Class 10. Any topic or question is explained:

- **as a story** (or a short explanation) in English, Telugu and Hindi, read aloud by the robot,
- **with pictures**: an AI-drawn diagram that explains the idea, plus emoji examples,
- **as a video**: a narrated cartoon made of AI-drawn story scenes, with subtitles and scene thumbnails.

It also has a syllabus browser with topics that unlock one by one, quizzes, weekly and monthly tests, badges, a Telugu ⇄ English translator and a grammar checker.

## Technology

- One static page (`public/index.html`), plain HTML/CSS/JS, no build step
- Netlify Functions (`netlify/functions`)
  - `/api/ai`: lessons, quizzes, translation and grammar through the Netlify AI Gateway (Gemini)
  - `/api/picture`: draws story scenes and diagrams with a Gemini image model
  - `/pics/:key`: serves the stored pictures
- Netlify Blobs caches lessons and pictures, so a topic is only generated once
- Netlify Image CDN resizes the pictures and serves them as WebP
- Browser speech synthesis provides the narration; progress is saved in the browser's localStorage

## Run locally

```bash
npm install
netlify dev
```

The AI Gateway starts working after the site has had its first production deploy.