# AGENTS.md

## Architecture
- `public/index.html` is the whole frontend: a single page in the user's original compact style (short global names like `u`, `D`, `cur`, `$`, template-string views rendered through `render()`). Keep edits in that style. There is no framework or build step.
- `netlify/functions/ai.mts` is a POST `{prompt, cacheKey?}` → `{text}` endpoint backed by `gemini-3-flash-preview`. When a `cacheKey` is given and the reply parses as JSON, it is stored in the `lessons` Blobs store. Change the `v1-` key prefix when the lesson JSON schema changes.
- `netlify/functions/picture.mts` is a POST `{prompt, kind: "scene"|"visual"}` → `{key}` endpoint. It adds a fixed style prefix, draws the picture with `gemini-3.1-flash-image`, and stores it in the `pictures` Blobs store keyed by a hash of the full prompt.
- `netlify/functions/pics.mts` serves `/pics/:key`. The page always loads these through `/.netlify/images?url=/pics/<key>&w=…&fm=webp`.

## Lesson JSON
`SCHEMA` and `RULES` in the page define it: `answer` and `story` (en/te/hi), `examples`, `scenes[{emoji, picture}]`, `visual`, `quiz`. The "video" splits the story into sentences and maps each sentence to a scene picture in proportion (`scIdx`). Pictures are requested at most 3 at a time (`want`/`pump`), and emoji placeholders show until they arrive.

## Conventions
- Functions use the modern v2 syntax (`export default` + `config.path`), so the AI Gateway credentials are injected at runtime. Don't add API-key checks.
- Student progress stays in localStorage, keyed by roll number and class. There are no server-side accounts yet.